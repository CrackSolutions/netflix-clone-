# Netflix-Website-Clone

This is a attempt to make netflix site by using html5,css3 and little bit of javascript. Note that it is just for my web Development practice purpose. :laughing:

There is lots of works to be done to make it look realistic. :smile:

Have a look [here](https://joykishansharma.github.io/Netflix-Website-Clone/)
